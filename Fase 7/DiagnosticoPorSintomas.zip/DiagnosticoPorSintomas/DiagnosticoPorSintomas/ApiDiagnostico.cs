﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiagnosticoPorSintomas
{
    internal class ApiDiagnostico
    {
  
            private readonly Dictionary<string, List<string>> conocimientoMedico;

            public ApiDiagnostico()
            {
                conocimientoMedico = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase)
            {
                {"fiebre", new List<string> {"Gripe", "Infección viral", "COVID-19", "Infección bacteriana"}},
                {"tos", new List<string> {"Resfriado común", "Bronquitis", "Asma", "Alergias"}},
                {"dolor de cabeza", new List<string> {"Migraña", "Tensión", "Deshidratación", "Sinusitis"}},
                {"dolor de garganta", new List<string> {"Faringitis", "Amigdalitis", "Resfriado común", "Alergias"}},
                {"fatiga", new List<string> {"Anemia", "Hipotiroidismo", "Depresión", "Síndrome de fatiga crónica"}},
                {"náuseas", new List<string> {"Gastritis", "Intoxicación alimentaria", "Migraña", "Embarazo"}}
            };
            }

            public List<string> ObtenerDiagnosticos(string sintomas)
            {
                var posiblesDiagnosticos = new List<string>();

                if (string.IsNullOrWhiteSpace(sintomas))
                    return posiblesDiagnosticos;

                foreach (var sintoma in sintomas.Split(',').Select(s => s.Trim()))
                {
                    if (conocimientoMedico.TryGetValue(sintoma, out var diagnosticos))
                    {
                        posiblesDiagnosticos.AddRange(diagnosticos);
                    }
                }

                return posiblesDiagnosticos.Distinct().ToList();
            }

            public void AgregarConocimiento(string sintoma, List<string> diagnosticos)
            {
                if (!conocimientoMedico.ContainsKey(sintoma))
                {
                    conocimientoMedico[sintoma] = new List<string>();
                }
                conocimientoMedico[sintoma].AddRange(diagnosticos);
            }
        }
    }


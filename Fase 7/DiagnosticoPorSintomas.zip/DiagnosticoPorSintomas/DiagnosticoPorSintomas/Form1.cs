﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiagnosticoPorSintomas
{
    public partial class Form1 : Form
    {
       
            private readonly ApiDiagnostico apiDiagnostico;

            public Form1()
            {
                InitializeComponent();
                apiDiagnostico = new ApiDiagnostico();
                ConfigurarControles();
            }

            private void ConfigurarControles()
            {
                txtSintomas.Text = "Ejemplo: fiebre, tos";
                txtSintomas.ForeColor = System.Drawing.Color.Gray;

                txtSintomas.Enter += (s, e) => {
                    if (txtSintomas.Text == "Ejemplo: fiebre, tos")
                    {
                        txtSintomas.Text = "";
                        txtSintomas.ForeColor = System.Drawing.Color.Black;
                    }
                };

                txtSintomas.Leave += (s, e) => {
                    if (string.IsNullOrWhiteSpace(txtSintomas.Text))
                    {
                        txtSintomas.Text = "Ejemplo: fiebre, tos";
                        txtSintomas.ForeColor = System.Drawing.Color.Gray;
                    }
                };
            }

            private void btnDiagnosticar_Click(object sender, EventArgs e)
            {
                string sintomas = txtSintomas.Text;

                if (sintomas == "Ejemplo: fiebre, tos" || string.IsNullOrWhiteSpace(sintomas))
                {
                    MessageBox.Show("Por favor, ingresa tus síntomas.", "Advertencia",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    var diagnosticos = apiDiagnostico.ObtenerDiagnosticos(sintomas);
                    MostrarResultados(diagnosticos);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error al procesar los síntomas: {ex.Message}", "Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            private void MostrarResultados(List<string> diagnosticos)
            {
                if (diagnosticos.Count > 0)
                {
                    lblResultado.Text = "Posibles diagnósticos:";
                    rtbDetalles.Clear();

                    foreach (var diagnostico in diagnosticos)
                    {
                        rtbDetalles.AppendText($"- {diagnostico}\n");
                    }

                    rtbDetalles.AppendText("\nNOTA: Este es solo un diagnóstico preliminar. " +
                                          "Por favor, consulta con un médico profesional.");
                }
                else
                {
                    lblResultado.Text = "Resultado:";
                    rtbDetalles.Text = "No se encontraron diagnósticos para los síntomas ingresados. " +
                                      "Por favor, consulta con un médico.";
                }
            }

        private void lblRerultado_Click(object sender, EventArgs e)
        {

        }
    }
    }


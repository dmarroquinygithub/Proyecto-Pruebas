﻿using CancelarCitas1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CancelarCitas1.Data
{
    public static class CitasData
    {
        public static List<Cita> Citas = new List<Cita>();

        static CitasData()
        {
           
            Citas.Add(new Cita
            {
                IdCita = 1,
                Paciente = "Ana Torres",
                Fecha = DateTime.Now.AddDays(1),
                Hora = new TimeSpan(9, 0, 0),
                Estado = "Activa"
            });
            Citas.Add(new Cita
            {
                IdCita = 2,
                Paciente = "Lucas Lopez",
                Fecha = DateTime.Now.AddDays(1),
                Hora = new TimeSpan(9, 0, 0),
                Estado = "Activa"
            });
        }
    }
}


﻿using CancelarCitas1.Data;
using CancelarCitas1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CancelarCitas1.Forms
{
    public partial class FormCitas : Form
    {
        public FormCitas()
        {
            InitializeComponent();
            btnCancelar.Click += btnCancelar_Click;
            btnReprogramar.Click += btnReprogramar_Click;

            
            calendarNuevaFecha.MinDate = DateTime.Today;
            CargarHoras();

            CargarCitas();

          
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
        }

        private void CargarCitas()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = CitasData.Citas.Where(c => c.Estado == "Activa").ToList();
            dataGridView1.Columns["Fecha"].DefaultCellStyle.Format = "dd/MM/yyyy";
        }

        private void CargarHoras()
        {
            comboBoxHora.Items.Clear();
            for (int hora = 8; hora <= 18; hora++)
            {
                for (int minuto = 0; minuto < 60; minuto += 30)
                {
                    TimeSpan tiempo = new TimeSpan(hora, minuto, 0);
                    string horaFormato = DateTime.Today.Add(tiempo).ToString("h:mm tt");
                    comboBoxHora.Items.Add(horaFormato);
                }
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            var cita = (Cita)dataGridView1.SelectedRows[0].DataBoundItem;

            
            calendarNuevaFecha.SetDate(cita.Fecha);
            string horaActual = DateTime.Today.Add(cita.Hora).ToString("h:mm tt");
            comboBoxHora.SelectedItem = horaActual;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona una cita primero.");
                return;
            }

            var cita = (Cita)dataGridView1.SelectedRows[0].DataBoundItem;
            cita.Estado = "Cancelada";
            MessageBox.Show("Cita cancelada.");
            CargarCitas();
        }

        private void btnReprogramar_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Selecciona una cita primero.");
                return;
            }

            if (comboBoxHora.SelectedItem == null)
            {
                MessageBox.Show("Por favor selecciona una hora válida.");
                return;
            }

            var cita = (Cita)dataGridView1.SelectedRows[0].DataBoundItem;

            DateTime nuevaFecha = calendarNuevaFecha.SelectionStart;
            string horaSeleccionada = comboBoxHora.SelectedItem.ToString();
            DateTime horaDateTime = DateTime.ParseExact(horaSeleccionada, "h:mm tt", null);
            TimeSpan nuevaHora = horaDateTime.TimeOfDay;

            cita.Fecha = nuevaFecha;
            cita.Hora = nuevaHora;

            MessageBox.Show($"Cita reprogramada para:\n{nuevaFecha:dd/MM/yyyy} a las {horaSeleccionada}",
                            "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);

            CargarCitas();
        }
    }
}

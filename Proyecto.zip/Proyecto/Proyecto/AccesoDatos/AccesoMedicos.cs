﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Proyecto.Modelos;

namespace Proyecto.AccesoDatos
{
    internal class AccesoMedicos
    {
        public AccesoMedicos() { }

        public Medico CrearMedico(int codigo, string nombres)
        {

        }
    }
}

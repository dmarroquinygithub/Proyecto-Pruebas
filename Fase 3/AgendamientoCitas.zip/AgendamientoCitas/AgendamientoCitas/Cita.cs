﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendamientoCitas
{
    public class Cita
    {
        public string Medico { get; set; }
        public string Paciente { get; set; }
        public DateTime FechaHora { get; set; }

        public Cita(string medico, string paciente, DateTime fechaHora)
        {
            Medico = medico ?? throw new ArgumentNullException(nameof(medico));
            Paciente = paciente ?? throw new ArgumentNullException(nameof(paciente));
            FechaHora = fechaHora;
        }
        public Cita()
        {
            Medico = string.Empty;
            Paciente = string.Empty;
            FechaHora = DateTime.Now;
        }
        public override string ToString()
        {
            return $" Dr. {Medico} con {Paciente} - {FechaHora:g}";
        }
    }
}

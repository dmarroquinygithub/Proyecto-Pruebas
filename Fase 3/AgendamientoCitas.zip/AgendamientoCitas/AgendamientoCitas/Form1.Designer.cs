﻿namespace AgendamientoCitas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtMedico = new TextBox();
            lblMensaje = new Label();
            monthCalendar = new MonthCalendar();
            dateTimePicker = new DateTimePicker();
            btnAgendar = new Button();
            lstCitas = new ListBox();
            label2 = new Label();
            txtPaciente = new TextBox();
            btnHistorial = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(282, 81);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 0;
            label1.Text = "Medico";
            // 
            // txtMedico
            // 
            txtMedico.Location = new Point(440, 78);
            txtMedico.Name = "txtMedico";
            txtMedico.Size = new Size(125, 27);
            txtMedico.TabIndex = 1;
            // 
            // lblMensaje
            // 
            lblMensaje.AutoSize = true;
            lblMensaje.Location = new Point(122, 81);
            lblMensaje.Name = "lblMensaje";
            lblMensaje.Size = new Size(0, 20);
            lblMensaje.TabIndex = 2;
            // 
            // monthCalendar
            // 
            monthCalendar.Location = new Point(273, 160);
            monthCalendar.Name = "monthCalendar";
            monthCalendar.TabIndex = 3;
            // 
            // dateTimePicker
            // 
            dateTimePicker.Format = DateTimePickerFormat.Time;
            dateTimePicker.Location = new Point(538, 340);
            dateTimePicker.Name = "dateTimePicker";
            dateTimePicker.ShowUpDown = true;
            dateTimePicker.Size = new Size(250, 27);
            dateTimePicker.TabIndex = 4;
            // 
            // btnAgendar
            // 
            btnAgendar.Location = new Point(324, 379);
            btnAgendar.Name = "btnAgendar";
            btnAgendar.Size = new Size(131, 29);
            btnAgendar.TabIndex = 5;
            btnAgendar.Text = "Agendar Cita";
            btnAgendar.UseVisualStyleBackColor = true;
            btnAgendar.Click += btnAgendar_Click;
            // 
            // lstCitas
            // 
            lstCitas.FormattingEnabled = true;
            lstCitas.Location = new Point(12, 103);
            lstCitas.Name = "lstCitas";
            lstCitas.Size = new Size(249, 264);
            lstCitas.TabIndex = 6;
            lstCitas.SelectedIndexChanged += lstCitas_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(282, 121);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 7;
            label2.Text = "Paciente";
            // 
            // txtPaciente
            // 
            txtPaciente.Location = new Point(440, 121);
            txtPaciente.Name = "txtPaciente";
            txtPaciente.Size = new Size(125, 27);
            txtPaciente.TabIndex = 8;
            // 
            // btnHistorial
            // 
            btnHistorial.Location = new Point(644, 61);
            btnHistorial.Name = "btnHistorial";
            btnHistorial.Size = new Size(94, 29);
            btnHistorial.TabIndex = 9;
            btnHistorial.Text = "Historial";
            btnHistorial.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnHistorial);
            Controls.Add(txtPaciente);
            Controls.Add(label2);
            Controls.Add(lstCitas);
            Controls.Add(btnAgendar);
            Controls.Add(dateTimePicker);
            Controls.Add(monthCalendar);
            Controls.Add(lblMensaje);
            Controls.Add(txtMedico);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Agendar Citas";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtMedico;
        private Label lblMensaje;
        private MonthCalendar monthCalendar;
        private DateTimePicker dateTimePicker;
        private Button btnAgendar;
        private ListBox lstCitas;
        private Label label2;
        private TextBox txtPaciente;
        private Button btnHistorial;
    }
}

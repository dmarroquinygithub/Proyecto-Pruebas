﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace AgendamientoCitas
{
    public class Agenda
    {
        private List<Cita> citas;

        public Agenda()
        {
            citas = new List<Cita>();
        }

        public bool AgendarCita(Cita nuevaCita, out string mensaje)
        {
            bool conflicto = citas.Any(c =>
                c.FechaHora == nuevaCita.FechaHora &&
                (c.Medico == nuevaCita.Medico || c.Paciente == nuevaCita.Paciente));

            if (conflicto)
            {
                mensaje = "Atencion, el médico o el paciente ya tiene una cita en ese horario.";
                return false;
            }

            citas.Add(nuevaCita);
            mensaje = "Cita agendada exitosamente.";
            return true;
        }

        public List<Cita> ObtenerCitas()
        {
            return citas.OrderBy(c => c.FechaHora).ToList();
        }

        internal bool AgregarCita(Cita nuevaCita)
        {
            bool conflicto = citas.Any(c =>
            c.Medico == nuevaCita.Medico && c.FechaHora == nuevaCita.FechaHora ||
            c.Paciente == nuevaCita.Paciente && c.FechaHora == nuevaCita.FechaHora);

            if (conflicto)
            {
                return false;
            }

            citas.Add(nuevaCita);
            return true;
        }

        public bool GuardarCitaEnDB(Cita cita)
        {
            ConexionDB conexionBD = new ConexionDB();
            try
            {
                ConexionDB conexionDB = new ConexionDB();
                using (MySqlConnection conn = conexionDB.ObtenerConexion())
                {
                    conn.Open();
                    string query = "INSERT INTO citas (medico, paciente, fecha_hora) VALUES (@medico, @paciente, @fecha_hora)";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@medico", cita.Medico);
                    cmd.Parameters.AddWithValue("@paciente", cita.Paciente);
                    cmd.Parameters.AddWithValue("@fecha_hora", cita.FechaHora);
                    cmd.ExecuteNonQuery();
                }
                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la cita en la base de datos: " + ex.Message);
                return false;
            }
            finally
            {
                conexionBD.CerrarConexion();    
            }
        }

        public List<Cita> ObtenerHistorialCitas()
        {
            List<Cita> historial = new List<Cita>();
            ConexionDB conexionDB = new ConexionDB();
            using (MySqlConnection conn = conexionDB.ObtenerConexion())
            {
               conn.Open();
               string query = "SELECT * FROM citas ORDER BY fecha_hora";
               MySqlCommand cmd = new MySqlCommand(query, conn);
               MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    historial.Add(new Cita
                    {
                        Medico = reader["medico"].ToString(),
                        Paciente = reader["paciente"].ToString(),
                        FechaHora = DateTime.Parse(reader["fecha_hora"].ToString())
                    });
                }
            }
            return historial;
            
        }
    }
}

using System.Windows.Forms;

namespace AgendamientoCitas
{
    public partial class Form1 : Form
    {   
        private ConexionDB db;
        private Agenda agenda;
        public Form1()
        {
            InitializeComponent();
            agenda = new Agenda();
            ActualizarListaCitas();
            db = new ConexionDB();
        }

        private void btnAgendar_Click(object sender, EventArgs e)
        {
            string medico = txtMedico.Text.Trim();
            string paciente = txtPaciente.Text.Trim();
            DateTime fechaHora = monthCalendar.SelectionStart.Date + dateTimePicker.Value.TimeOfDay;

            if (string.IsNullOrEmpty(medico) || string.IsNullOrEmpty(paciente))
            {
                MessageBox.Show("Debe ingresar el nombre del m�dico y del paciente.");
                return;
            }

            Cita nuevaCita = new Cita(medico, paciente, fechaHora);

            if (!agenda.AgregarCita(nuevaCita))
            {
                MessageBox.Show("Ya existe una cita en ese horario para ese m�dico o paciente.");
            }
            else
            {
                agenda.GuardarCitaEnDB(nuevaCita);
                lstCitas.Items.Add(nuevaCita);
                MessageBox.Show("Cita agendada correctamente.");
            }
            
        }

        private void ActualizarListaCitas()
        {
            lstCitas.Items.Clear();
            foreach (var cita in agenda.ObtenerCitas())
            {
                lstCitas.Items.Add(cita);
            }
        }
        private void lstCitas_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCitas.SelectedItem != null)
            {
                MessageBox.Show(lstCitas.SelectedItem.ToString(), "Detalles de la Cita");
            }
        }

        private void btnHistorial_Click(object sender, EventArgs e)
        { 
            lstCitas.Items.Clear();
            var historial = agenda.ObtenerHistorialCitas();
            foreach (var cita in historial)
            {
                lstCitas.Items.Add($"{cita.FechaHora} - Dr. {cita.Medico} - Paciente {cita.Paciente}");
            }

        }
    }
}

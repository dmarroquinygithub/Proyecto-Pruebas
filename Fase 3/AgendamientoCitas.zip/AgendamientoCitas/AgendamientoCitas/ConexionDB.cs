﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace AgendamientoCitas
{
    public class ConexionDB
    {
        private MySqlConnection conexion;
        private string connectionString = "server=localhost;user=root;password=JALAPA123;database=Citas2;";

        public MySqlConnection ObtenerConexion()
        {
            return new MySqlConnection(connectionString);
        }

        public MySqlConnection AbrirConexion()
        {
            try
            {
                conexion = new MySqlConnection(connectionString);
                conexion.Open();
                return conexion;
            }
            catch (MySqlException ex)
            {
                throw new Exception("Error al conectar a la base de datos: " + ex.Message);
            }
        }

        public void CerrarConexion()
        {
            if (conexion != null && conexion.State == System.Data.ConnectionState.Open)
            {
                conexion.Close();
            }
        }
    }
}
